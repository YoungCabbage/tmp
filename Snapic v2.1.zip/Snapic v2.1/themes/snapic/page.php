<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('post.php'); ?>